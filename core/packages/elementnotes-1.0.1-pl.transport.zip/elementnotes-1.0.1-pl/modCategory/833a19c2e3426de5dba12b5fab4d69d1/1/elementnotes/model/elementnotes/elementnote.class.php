<?php
class elementNote extends xPDOObject {}