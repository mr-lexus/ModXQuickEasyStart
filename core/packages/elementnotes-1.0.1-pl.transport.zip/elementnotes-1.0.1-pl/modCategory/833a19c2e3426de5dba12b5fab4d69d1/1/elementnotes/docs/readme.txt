--------------------
elementNotes
--------------------
Author: Sergey Shlokov <sergant210@bk.ru>
--------------------

An Extra for MODx Revolution, extending the basic elements abilities by adding a new tab Notes. Now you can not be afraid of losing notes when updating element.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/elementNotes/issues