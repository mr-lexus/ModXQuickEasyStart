<?php
require_once (dirname(dirname(__FILE__)) . '/elementnote.class.php');
class elementNote_mysql extends elementNote {}