<?php
$_lang['Notes'] = 'Notes';
$_lang['elementNote_panelDesc'] = 'Here you can save your notes and comments without fear of losing them when an element is updated.';
$_lang['elementNote_err_nf'] = '[elementNote] Object is not found.';
$_lang['elementNote_err_remove'] = '[elementNote] Failed to delete the note of object "[[+type]]" with id=[[+id]].';