<?php
$_lang['Notes'] = 'Заметки';
$_lang['elementNote_panelDesc'] = 'Здесь вы можете сохранять свои заметки и комментарии, не боясь их потерять при обновлении элемента.';
$_lang['elementNote_err_nf'] = '[elementNote] Объект  не найден.';
$_lang['elementNote_err_remove'] = '[elementNote] Не удалось удалить заметку объекта "[[+type]]" с id=[[+id]].';