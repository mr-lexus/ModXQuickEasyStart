--------------------
autoRedirector
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

Tracking changes in the urls and adding rules for redirect
