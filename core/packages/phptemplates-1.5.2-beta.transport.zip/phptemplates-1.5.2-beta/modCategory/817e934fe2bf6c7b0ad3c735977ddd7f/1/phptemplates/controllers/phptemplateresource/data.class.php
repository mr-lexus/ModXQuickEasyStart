<?php
/**
 * Author: proxyfabio
 * Date: 29.11.12
 *
 * @package: phpTemplates
 * @subpackage: build
 */

class phpTemplateResourceDataManagerController extends ResourceDataManagerController {}