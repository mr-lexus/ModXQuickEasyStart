<?php
/**
 * Default Russian Lexicon Entries
 *
 * @subpackage lexicon
 */
$_lang['phptemplates_resource_create'] = 'Документ с php-шаблоном';
$_lang['phptemplates_resource_create_here'] = 'Дочерний документ с php-шаблоном';
$_lang['phptemplates_resource'] = 'Документ с php-шаблоном';
$_lang['resource'] = 'Ресурс';