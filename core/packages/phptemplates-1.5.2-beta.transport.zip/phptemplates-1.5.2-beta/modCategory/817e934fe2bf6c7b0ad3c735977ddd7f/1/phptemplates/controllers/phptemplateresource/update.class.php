<?php
/**
 * The update manager controller
 *
 */
class phpTemplateResourceUpdateManagerController extends ResourceUpdateManagerController {
	 
}
