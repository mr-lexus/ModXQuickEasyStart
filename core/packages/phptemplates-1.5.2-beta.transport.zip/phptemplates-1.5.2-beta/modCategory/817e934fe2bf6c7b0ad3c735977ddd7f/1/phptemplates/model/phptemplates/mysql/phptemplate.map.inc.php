<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['phpTemplate']= array (
  'package' => 'modx',
  'version' => '1.1',
  'table' => 'site_templates',
  'extends' => 'modTemplate',
  'fields' => 
  array ( 
  ), 
);
