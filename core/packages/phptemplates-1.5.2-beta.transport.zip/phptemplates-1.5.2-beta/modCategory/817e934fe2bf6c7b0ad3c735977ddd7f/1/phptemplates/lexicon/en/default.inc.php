<?php
/**
 * Default English Lexicon Entries
 *
 * @subpackage lexicon
 */
$_lang['phptemplates_resource_create'] = 'Resource with php-template';
$_lang['phptemplates_resource_create_here'] = 'Create resource with php-template';
$_lang['phptemplates_resource'] = 'Resource with php-template';
$_lang['resource'] = 'Ресурс';


