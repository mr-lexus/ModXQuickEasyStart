<?php
$location = 'resourcelegalform/';
require_once dirname(__FILE__).'/index.php';