<?php
$this->loadClass('ShopmodxSimpleObject');
class ShopmodxProduct extends ShopmodxSimpleObject {}