<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresourceproduct.class.php');
class ShopmodxResourceProduct_mysql extends ShopmodxResourceProduct {}