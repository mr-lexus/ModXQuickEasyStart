<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    'ShopmodxResource',
    'ShopmodxResourceProductModel',
    'ShopmodxResourceProduct',
    'ShopmodxResourceCurrency',
    //'ShopmodxResourceWarehouse',
    //'ShopmodxResourceLegalForm',
    //'ShopmodxResourceClient',
  ),
);