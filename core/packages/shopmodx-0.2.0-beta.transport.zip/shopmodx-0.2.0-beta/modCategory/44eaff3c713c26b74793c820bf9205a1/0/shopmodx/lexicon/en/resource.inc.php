<?php

// Resource
$_lang['shopmodx.resource'] = "shopModx Document";
$_lang['shopmodx.resource_create'] = "shopModx Document";
$_lang['shopmodx.resource_create_here'] = "shopModx Document";

// Category
$_lang['shopmodx.resource_category'] = "Category";
$_lang['shopmodx.resource_category_create'] = "Category";
$_lang['shopmodx.resource_category_create_here'] = "Category";

// Product
$_lang['shopmodx.resource_product'] = "Product";
$_lang['shopmodx.resource_product_create'] = "Product";
$_lang['shopmodx.resource_product_create_here'] = "Product";

// Producer
$_lang['shopmodx.resource_producer'] = "Producer";
$_lang['shopmodx.resource_producer_create'] = "Producer";
$_lang['shopmodx.resource_producer_create_here'] = "Producer";

// Warehouse
$_lang['shopmodx.resource_warehouse'] = "Warehouse";
$_lang['shopmodx.resource_warehouse_create'] = "Warehouse";
$_lang['shopmodx.resource_warehouse_create_here'] = "Warehouse";

// Vendor
$_lang['shopmodx.resource_vendor'] = "Vendor";
$_lang['shopmodx.resource_vendor_create'] = "Vendor";
$_lang['shopmodx.resource_vendor_create_here'] = "Vendor";

// LegalForm
$_lang['shopmodx.resource_legalform'] = "Legal form";
$_lang['shopmodx.resource_legalform_create'] = "Legal form";
$_lang['shopmodx.resource_legalform_create_here'] = "Legal form";

// Client
$_lang['shopmodx.resource_client'] = "Client";
$_lang['shopmodx.resource_client_create'] = "Client";
$_lang['shopmodx.resource_client_create_here'] = "Client";

// Currency
$_lang['shopmodx.resource_currency'] = "Currency";
$_lang['shopmodx.resource_currency_create'] = "Currency";
$_lang['shopmodx.resource_currency_create_here'] = "Currency";

// ProductModel
$_lang['shopmodx.resource_productmodel'] = "Product model";
$_lang['shopmodx.resource_productmodel_create'] = "Product model";
$_lang['shopmodx.resource_productmodel_create_here'] = "Product model";