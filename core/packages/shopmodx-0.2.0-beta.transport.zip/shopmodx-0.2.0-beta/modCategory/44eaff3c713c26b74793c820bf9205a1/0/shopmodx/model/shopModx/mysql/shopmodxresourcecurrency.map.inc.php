<?php
$xpdo_meta_map['ShopmodxResourceCurrency']= array (
  'package' => 'Shopmodx',
  'version' => '1.1',
  'extends' => 'ShopmodxResource',
  'fields' => 
  array (
      'class_key' => 'ShopmodxResourceCurrency',
  ),
  'fieldMeta' => 
  array (),
);
