<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresourcewarehouse.class.php');
class ShopmodxResourceWarehouse_mysql extends ShopmodxResourceWarehouse {}