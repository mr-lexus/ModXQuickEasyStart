<?php

// Resource
$_lang['shopmodx.resource'] = "Документ shopModx";
$_lang['shopmodx.resource_create'] = "Документ shopModx";
$_lang['shopmodx.resource_create_here'] = "Документ shopModx";

// Category
$_lang['shopmodx.resource_category'] = "Категория";
$_lang['shopmodx.resource_category_create'] = "Категорию";
$_lang['shopmodx.resource_category_create_here'] = "Дочернюю категорию";

// Product
$_lang['shopmodx.resource_product'] = "Товар";
$_lang['shopmodx.resource_product_create'] = "Товар";
$_lang['shopmodx.resource_product_create_here'] = "Дочерний товар";

// Producer
$_lang['shopmodx.resource_producer'] = "Производитель";
$_lang['shopmodx.resource_producer_create'] = "Производителя";
$_lang['shopmodx.resource_producer_create_here'] = "Дочернего производителя";

// Warehouse
$_lang['shopmodx.resource_productmodel'] = "Склад";
$_lang['shopmodx.resource_productmodel_create'] = "Склад";
$_lang['shopmodx.resource_productmodel_create_here'] = "Дочерний склад";

// Vendor
$_lang['shopmodx.resource_vendor'] = "Поставщик";
$_lang['shopmodx.resource_vendor_create'] = "Поставщика";
$_lang['shopmodx.resource_vendor_create_here'] = "Дочернего поставщика";

// LegalForm
$_lang['shopmodx.resource_legalform'] = "Правовая форма";
$_lang['shopmodx.resource_legalform_create'] = "Правовую форму";
$_lang['shopmodx.resource_legalform_create_here'] = "Правовую форму";

// Client
$_lang['shopmodx.resource_client'] = "Клиент";
$_lang['shopmodx.resource_client_create'] = "Клиента";
$_lang['shopmodx.resource_client_create_here'] = "Клиента";

// Currency
$_lang['shopmodx.resource_currency'] = "Валюта";
$_lang['shopmodx.resource_currency_create'] = "Валюту";
$_lang['shopmodx.resource_currency_create_here'] = "Валюту";

// ProductModel
$_lang['shopmodx.resource_productmodel'] = "Модель товара";
$_lang['shopmodx.resource_productmodel_create'] = "Модель товара";
$_lang['shopmodx.resource_productmodel_create_here'] = "Модель товара";
