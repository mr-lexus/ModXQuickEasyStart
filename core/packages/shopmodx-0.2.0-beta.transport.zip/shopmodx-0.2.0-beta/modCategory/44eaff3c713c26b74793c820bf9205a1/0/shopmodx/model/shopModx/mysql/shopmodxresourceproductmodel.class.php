<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresourceproductmodel.class.php');
class ShopmodxResourceProductModel_mysql extends ShopmodxResourceProductModel {}