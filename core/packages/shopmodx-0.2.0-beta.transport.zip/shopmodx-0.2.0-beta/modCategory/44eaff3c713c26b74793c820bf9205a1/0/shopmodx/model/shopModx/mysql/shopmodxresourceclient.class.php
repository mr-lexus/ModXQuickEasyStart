<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresourceclient.class.php');
class ShopmodxResourceClient_mysql extends ShopmodxResourceClient {}