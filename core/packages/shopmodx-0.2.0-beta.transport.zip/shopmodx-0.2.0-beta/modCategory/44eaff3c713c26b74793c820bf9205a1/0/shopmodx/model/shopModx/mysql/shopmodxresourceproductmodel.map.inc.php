<?php
$xpdo_meta_map['ShopmodxResourceProductModel']= array (
  'package' => 'Shopmodx',
  'version' => '1.1',
  'extends' => 'ShopmodxResource',
  'fields' => 
  array (
      'class_key' => 'ShopmodxResourceProductModel',
  ),
  'fieldMeta' => 
  array (),
);
