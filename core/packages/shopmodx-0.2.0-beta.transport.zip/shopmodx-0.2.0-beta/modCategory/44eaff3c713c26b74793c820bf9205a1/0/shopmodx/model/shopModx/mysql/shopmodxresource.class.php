<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresource.class.php');
class ShopmodxResource_mysql extends ShopmodxResource {}