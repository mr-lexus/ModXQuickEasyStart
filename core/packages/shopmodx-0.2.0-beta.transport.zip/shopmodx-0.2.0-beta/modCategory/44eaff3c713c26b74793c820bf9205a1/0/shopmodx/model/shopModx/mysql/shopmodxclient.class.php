<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxclient.class.php');
class ShopmodxClient_mysql extends ShopmodxClient {}