<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresourcelegalform.class.php');
class ShopmodxResourceLegalForm_mysql extends ShopmodxResourceLegalForm {}