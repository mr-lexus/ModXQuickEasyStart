<?php
$xpdo_meta_map['ShopmodxResourceLegalForm']= array (
  'package' => 'Shopmodx',
  'version' => '1.1',
  'extends' => 'ShopmodxResource',
  'fields' => 
  array (
      'class_key' => 'ShopmodxResourceLegalForm',
  ),
  'fieldMeta' => 
  array (),
);
