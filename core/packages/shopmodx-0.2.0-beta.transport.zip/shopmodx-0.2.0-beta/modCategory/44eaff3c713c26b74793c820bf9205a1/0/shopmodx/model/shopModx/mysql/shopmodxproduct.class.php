<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxproduct.class.php');
class ShopmodxProduct_mysql extends ShopmodxProduct {}