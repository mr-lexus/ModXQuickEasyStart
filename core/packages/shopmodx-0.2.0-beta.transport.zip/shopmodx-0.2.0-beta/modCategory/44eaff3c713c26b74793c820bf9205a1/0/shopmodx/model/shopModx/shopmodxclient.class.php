<?php
$this->loadClass('ShopmodxSimpleObject');
class ShopmodxClient extends ShopmodxSimpleObject{}