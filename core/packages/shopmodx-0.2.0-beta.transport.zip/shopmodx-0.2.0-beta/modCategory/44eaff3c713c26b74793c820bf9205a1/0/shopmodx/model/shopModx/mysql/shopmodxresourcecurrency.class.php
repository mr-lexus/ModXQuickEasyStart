<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxresourcecurrency.class.php');
class ShopmodxResourceCurrency_mysql extends ShopmodxResourceCurrency {}