<?php
require_once (dirname(dirname(__FILE__)) . '/shopmodxsimpleobject.class.php');
class ShopmodxSimpleObject_mysql extends ShopmodxSimpleObject {}