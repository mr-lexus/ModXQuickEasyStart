<?php


require_once MODX_MANAGER_PATH. "controllers/default/resource/data.class.php";

class ShopxResourceProductDataManagerController extends ResourceDataManagerController{
    
}