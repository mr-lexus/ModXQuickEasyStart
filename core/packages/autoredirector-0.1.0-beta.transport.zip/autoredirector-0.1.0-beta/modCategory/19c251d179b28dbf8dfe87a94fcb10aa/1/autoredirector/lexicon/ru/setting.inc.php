<?php

$_lang['area_autoredirector_main'] = 'Основные';

$_lang['setting_autoredirector_some_setting'] = 'Какая-то настройка';
$_lang['setting_autoredirector_some_setting_desc'] = 'Это описание для какой-то настройки';