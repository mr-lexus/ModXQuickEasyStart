--------------------
yTranslit
--------------------

This extension generates an alias to the resource through a translate service from Yandex.

The principle of operation is similar to the component translit. 
To start working specify the correct direction of the translation in a system parameter "friendly_alias_ytranslit_url" by changing the parameter in the $_GET &lang=ru-en.

The default direction of translate is ru-en.