<?php

$_lang['composerconsole'] = 'Composer Console';
$_lang['composerconsole.tab_console'] = 'Console';
$_lang['composerconsole.console_intro_msg'] = 'Консоль выполнения composer команд.<br/>
Например, команда "show -i" покажет все установленные пакеты.<br/>
<a href="https://getcomposer.org/doc/03-cli.md#command-line-interface-commands" target="_blank">Справка по командам.</a>';
$_lang['composerconsole.tab_composerjson'] = 'composer.json';
$_lang['composerconsole.composerjson_intro_msg'] = 'Содержимое файла composer.json';
$_lang['composerconsole.run_button'] = 'Выполнить';
$_lang['composerconsole.save_json_button'] = 'Сохранить';
$_lang['composerconsole.cancel_json_button'] = 'Отменить';
$_lang['composerconsole.err_json_nf'] = 'Файл composer.json не существует. Выполните команду "init".';
$_lang['composerconsole.err_json_save'] = 'Не удается записать файл composer.json.';

