<?php
require_once (dirname(dirname(__FILE__)) . '/vpevent.class.php');
class vpEvent_mysql extends vpEvent {}