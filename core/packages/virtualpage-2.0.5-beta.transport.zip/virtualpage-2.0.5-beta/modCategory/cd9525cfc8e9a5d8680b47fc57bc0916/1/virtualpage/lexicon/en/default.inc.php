<?php

include_once 'errors.inc.php';
include_once 'manager.inc.php';
include_once 'setting.inc.php';

$_lang['virtualpage'] = 'VirtualPage';
$_lang['virtualpage_menu_desc'] = 'Управление виртуальными страницами.';

$_lang['virtualpage_settings'] = 'Настройки';

$_lang['virtualpage_routes'] = 'Маршруты';
$_lang['virtualpage_routes_intro'] = 'Панель управления маршрутами.';

$_lang['virtualpage_events'] = 'События';
$_lang['virtualpage_events_intro'] = 'Панель управления событиями.';

$_lang['virtualpage_handlers'] = 'Обработчики';
$_lang['virtualpage_handlers_intro'] = 'Панель управления обработчиками.';
