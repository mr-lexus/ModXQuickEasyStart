<?php
require_once (dirname(dirname(__FILE__)) . '/vphandler.class.php');
class vpHandler_mysql extends vpHandler {}