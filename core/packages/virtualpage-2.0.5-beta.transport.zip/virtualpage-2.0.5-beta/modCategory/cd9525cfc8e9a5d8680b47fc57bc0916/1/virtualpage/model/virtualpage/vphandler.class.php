<?php

class vpHandler extends xPDOSimpleObject
{
}