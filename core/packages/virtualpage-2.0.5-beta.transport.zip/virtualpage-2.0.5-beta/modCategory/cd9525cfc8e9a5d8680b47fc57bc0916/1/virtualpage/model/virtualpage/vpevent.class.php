<?php

class vpEvent extends xPDOSimpleObject
{

}