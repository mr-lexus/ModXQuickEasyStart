<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => 'cacheRegenerator-1.0.0-beta
======================================
- First Release

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '86124878345ecaec6f6cd71df072f22f',
      'native_key' => 'cacheregenerator',
      'filename' => 'modNamespace/a0672216ea9760c2e82f5895c1ed6c51.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8b572cd45ee8961d0d89221eb1e5c9ed',
      'native_key' => 'cacheregenerator',
      'filename' => 'modNamespace/c6ec36d3068e2f3fc4bc7f11912f1b84.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56a3e8c3ae288979631a4b8fae4aaeed',
      'native_key' => 'cacheregenerator.regenerate_docs_on_doc_save',
      'filename' => 'modSystemSetting/5d0266fda933407b35630078f76e5712.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09088ed44fdb8a092db9efde40904d74',
      'native_key' => 'cacheregenerator.regenerate_docs_on_site_refresh',
      'filename' => 'modSystemSetting/d203309460512f271fa40308b7db301a.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8a47d977feefda91647f92f8b2f6f67',
      'native_key' => 'cacheregenerator.regenerate_unsearchable_docs',
      'filename' => 'modSystemSetting/5ff4fbb5a348555ce2d10d122ad22348.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09a2e5e34c7215bbcdaadc0e558b4e82',
      'native_key' => 'cacheregenerator.exclude_docs_id',
      'filename' => 'modSystemSetting/3bd92dfeb00c871e3c1b3e763de3a2cf.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecd1a53a865a53d0170428e1ab0115b4',
      'native_key' => 'cacheregenerator.exclude_doc_templates_id',
      'filename' => 'modSystemSetting/8c090da7b72c5e6f485c62c74dd61231.vehicle',
      'namespace' => 'cacheregenerator',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8e3c79c58b3a9b68fbf303c2ff6ef8e7',
      'native_key' => 1,
      'filename' => 'modCategory/264d2a2cb0c2b052e7aaf48bf104f12e.vehicle',
      'namespace' => 'cacheregenerator',
    ),
  ),
);