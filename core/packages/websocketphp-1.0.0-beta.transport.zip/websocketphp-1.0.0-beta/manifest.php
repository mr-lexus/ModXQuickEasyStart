<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => 'websocketphp-1.0.0-beta
==============================================
- First release

',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '317fe161d758ae9678d0061fc3766dae',
      'native_key' => 'websocketphp',
      'filename' => 'modNamespace/81bb025a01393808b49dd8635122f0ae.vehicle',
      'namespace' => 'websocketphp',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '78e2494f63e9d8e3fcee0ea0eda3a884',
      'native_key' => 'websocketphp',
      'filename' => 'modNamespace/5ce4a6f8c8fd4c035df56dc7e26123de.vehicle',
      'namespace' => 'websocketphp',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4df3f59f10620c338c5b6ea9db7de2b2',
      'native_key' => 'websocketphp.host',
      'filename' => 'modSystemSetting/7dd98b29e10c064039013d5b12c10abb.vehicle',
      'namespace' => 'websocketphp',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd0e4c2fe40ed2fac70d0df0f4bd8a8e0',
      'native_key' => 1,
      'filename' => 'modCategory/17f15b7283dd5af807de3f5a137ff479.vehicle',
      'namespace' => 'websocketphp',
    ),
  ),
);