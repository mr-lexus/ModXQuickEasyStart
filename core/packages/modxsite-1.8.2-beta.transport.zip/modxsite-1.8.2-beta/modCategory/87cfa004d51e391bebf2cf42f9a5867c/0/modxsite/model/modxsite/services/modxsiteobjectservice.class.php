<?php

require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/processors/site/web/object.class.php';

class modxsiteObjectService extends modSiteWebObjectProcessor{
    
}

