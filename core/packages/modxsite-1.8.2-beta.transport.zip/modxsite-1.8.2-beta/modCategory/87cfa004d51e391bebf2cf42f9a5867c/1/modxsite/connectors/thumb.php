<?php

$action = 'site/web/resources/images/thumb';

require dirname(__FILE__) . '/connector.php';
